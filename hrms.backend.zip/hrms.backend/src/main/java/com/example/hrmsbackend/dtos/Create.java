package com.example.hrmsbackend.dtos;

public interface Create {
}
